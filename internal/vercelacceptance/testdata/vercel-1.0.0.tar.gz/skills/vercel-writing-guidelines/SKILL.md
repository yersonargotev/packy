---
name: writing-guidelines
description: Review docs/prose for Writing Guidelines compliance. Use when asked to "review my docs", "check writing style", "audit prose", "review docs voice and tone", or "check this page against the writing handbook".
metadata:
  author: vercel
  version: "1.0.0"
  argument-hint: <file-or-pattern>
---

# Writing Guidelines

Review files for compliance with Writing Guidelines.

## How It Works

1. Read the sealed package-local guidelines from `../../references/vercel-writing-guidelines-command.md`
2. Read the specified files (or prompt user for files/pattern)
3. Check against all rules in the sealed guidelines
4. Output findings in the terse `file:line` format

## Guidelines Source

Read the complete sealed guidelines from `../../references/vercel-writing-guidelines-command.md` relative to this `SKILL.md`. Do not fetch moving upstream content. The sealed content contains all rules and output format instructions.

## Usage

When a user provides a file or pattern argument:
1. Read the sealed package-local guidelines named above
2. Read the specified files
3. Apply all rules from the sealed guidelines
4. Output findings using the format specified in the guidelines

If no files specified, ask the user which files to review.
